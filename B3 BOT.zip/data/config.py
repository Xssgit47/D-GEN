BOT_TOKEN = '6967383365:AAE5uqpGWq_nWhF7-WdX8hzz3KWB7UMPuqs'

PREFIX = "!/."

ANTISPAM = int(120)

OWNER = 7353019847

APP_ID = "19082916"

API_HASH = 'ba584795667a2a207a72e6a5cd6e0711'

SESSION = ""

OWNERID = int(7353019847)

OWNER_NAME = "<a href='tg://user?id=7345260405'>⏤͟͞D3</a>"

CHANNEL = "https://t.me/TNT_NETWORK_TEAM"

GROUP = "https://t.me/+nDZcN5MZg7QwZDll"

OWNER_LINK = "https://t.me/fnxdanger"

from database import check_user, check_admin

def check_owner(id):
  if id == OWNER: return True
def ok(id):
  if check_owner(id):
    user = "OWNER"
    return user
  if check_admin(id) == True:
    user = "ADMIN"
    return user

  elif check_user(id) == True:
    user = "PAID"
    return user

  elif check_user(id) == False or check_admin(id) == False:
    user = "FREE"
    return user

  else:
    user = "FREE"
    return user
