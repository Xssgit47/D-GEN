from .admin import dp
from .callback import dp
from .translator import dp
from .phone_ip import dp
from .ssk_sk import dp
from .spotify_sk import dp
from .filter import dp

__all__ = ['dp']